controlled json11 header
