#include <stdint.h>
#include <string.h>
void op_kernel_0(void **buffers, const int32_t *scalars) { memmove(buffers[0], buffers[1], 36); }
extern void op_impl_1(void *, void *, void *);
void op_kernel_1(void **buffers, const int32_t *scalars) { op_impl_1(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_2(void *, void *, void *, void *);
void op_kernel_2(void **buffers, const int32_t *scalars) { op_impl_2(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_3(void *, void *, void *, void *);
void op_kernel_3(void **buffers, const int32_t *scalars) { op_impl_3(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_4(void *, void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_4(void **buffers, const int32_t *scalars) { op_impl_4(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], buffers[6], scalars[0]); }
void op_kernel_5(void **buffers, const int32_t *scalars) { memmove(buffers[0], buffers[1], 2096); }
extern void op_impl_6(void *, void *, void *, int32_t);
void op_kernel_6(void **buffers, const int32_t *scalars) { op_impl_6(buffers[0], buffers[1], buffers[2], scalars[0]); }
extern void op_impl_7(void *, void *, void *, int32_t);
void op_kernel_7(void **buffers, const int32_t *scalars) { op_impl_7(buffers[0], buffers[1], buffers[2], scalars[0]); }
extern void op_impl_8(void *, void *, void *);
void op_kernel_8(void **buffers, const int32_t *scalars) { op_impl_8(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_9(void *, void *, void *);
void op_kernel_9(void **buffers, const int32_t *scalars) { op_impl_9(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_10(void *, void *, void *, void *);
void op_kernel_10(void **buffers, const int32_t *scalars) { op_impl_10(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_11(void *, void *, int32_t);
void op_kernel_11(void **buffers, const int32_t *scalars) { op_impl_11(buffers[0], buffers[1], scalars[0]); }
extern void op_impl_12(void *, void *);
void op_kernel_12(void **buffers, const int32_t *scalars) { op_impl_12(buffers[0], buffers[1]); }
extern void op_impl_13(void *, void *);
void op_kernel_13(void **buffers, const int32_t *scalars) { op_impl_13(buffers[0], buffers[1]); }
extern void op_impl_14(void *, void *, void *, void *, int32_t);
void op_kernel_14(void **buffers, const int32_t *scalars) { op_impl_14(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_15(void *, void *, int32_t);
void op_kernel_15(void **buffers, const int32_t *scalars) { op_impl_15(buffers[0], buffers[1], scalars[0]); }
extern void op_impl_16(void *, void *);
void op_kernel_16(void **buffers, const int32_t *scalars) { op_impl_16(buffers[0], buffers[1]); }
extern void op_impl_17(void *, void *);
void op_kernel_17(void **buffers, const int32_t *scalars) { op_impl_17(buffers[0], buffers[1]); }
extern void op_impl_18(void *, void *, void *, void *, void *, int32_t);
void op_kernel_18(void **buffers, const int32_t *scalars) { op_impl_18(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_19(void *, void *, void *, void *);
void op_kernel_19(void **buffers, const int32_t *scalars) { op_impl_19(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_20(void *, void *, void *, void *, int32_t);
void op_kernel_20(void **buffers, const int32_t *scalars) { op_impl_20(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_21(void *, void *, void *, void *, int32_t);
void op_kernel_21(void **buffers, const int32_t *scalars) { op_impl_21(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_22(void *, void *, void *, void *, int32_t);
void op_kernel_22(void **buffers, const int32_t *scalars) { op_impl_22(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_23(void *, void *, void *, void *, int32_t);
void op_kernel_23(void **buffers, const int32_t *scalars) { op_impl_23(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_24(void *, void *, void *, void *, int32_t);
void op_kernel_24(void **buffers, const int32_t *scalars) { op_impl_24(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_25(void *, void *, void *, void *, int32_t);
void op_kernel_25(void **buffers, const int32_t *scalars) { op_impl_25(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_26(void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_26(void **buffers, const int32_t *scalars) { op_impl_26(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], scalars[0]); }
extern void op_impl_27(void *, void *, void *, void *, int32_t);
void op_kernel_27(void **buffers, const int32_t *scalars) { op_impl_27(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_28(void *, void *, void *, void *, int32_t);
void op_kernel_28(void **buffers, const int32_t *scalars) { op_impl_28(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_29(void *, void *, void *, void *, int32_t);
void op_kernel_29(void **buffers, const int32_t *scalars) { op_impl_29(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_30(void *, void *, void *, void *, int32_t);
void op_kernel_30(void **buffers, const int32_t *scalars) { op_impl_30(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_31(void *, void *, void *, void *, int32_t);
void op_kernel_31(void **buffers, const int32_t *scalars) { op_impl_31(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_32(void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_32(void **buffers, const int32_t *scalars) { op_impl_32(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], scalars[0]); }
extern void op_impl_33(void *, void *, void *, void *, int32_t);
void op_kernel_33(void **buffers, const int32_t *scalars) { op_impl_33(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_34(void *, void *, void *, void *, int32_t);
void op_kernel_34(void **buffers, const int32_t *scalars) { op_impl_34(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_35(void *, void *, void *, void *, int32_t);
void op_kernel_35(void **buffers, const int32_t *scalars) { op_impl_35(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_36(void *, void *, void *, void *, int32_t);
void op_kernel_36(void **buffers, const int32_t *scalars) { op_impl_36(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_37(void *, void *, void *, void *, int32_t);
void op_kernel_37(void **buffers, const int32_t *scalars) { op_impl_37(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_38(void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_38(void **buffers, const int32_t *scalars) { op_impl_38(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], scalars[0]); }
extern void op_impl_39(void *, void *, void *, void *, int32_t);
void op_kernel_39(void **buffers, const int32_t *scalars) { op_impl_39(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_40(void *, void *, void *, void *, int32_t);
void op_kernel_40(void **buffers, const int32_t *scalars) { op_impl_40(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_41(void *, void *, void *, void *);
void op_kernel_41(void **buffers, const int32_t *scalars) { op_impl_41(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_42(void *, void *, void *, void *, int32_t);
void op_kernel_42(void **buffers, const int32_t *scalars) { op_impl_42(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_43(void *, void *, void *, void *, int32_t);
void op_kernel_43(void **buffers, const int32_t *scalars) { op_impl_43(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_44(void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_44(void **buffers, const int32_t *scalars) { op_impl_44(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], scalars[0]); }
extern void op_impl_45(void *, void *, void *, void *, int32_t);
void op_kernel_45(void **buffers, const int32_t *scalars) { op_impl_45(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_46(void *, void *);
void op_kernel_46(void **buffers, const int32_t *scalars) { op_impl_46(buffers[0], buffers[1]); }
extern void op_impl_47(void *, void *, void *, void *);
void op_kernel_47(void **buffers, const int32_t *scalars) { op_impl_47(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_48(void *, void *, void *, void *);
void op_kernel_48(void **buffers, const int32_t *scalars) { op_impl_48(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_49(void *, void *, void *);
void op_kernel_49(void **buffers, const int32_t *scalars) { op_impl_49(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_50(void *, void *, void *, void *, int32_t);
void op_kernel_50(void **buffers, const int32_t *scalars) { op_impl_50(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_51(void *, void *, void *, void *, int32_t);
void op_kernel_51(void **buffers, const int32_t *scalars) { op_impl_51(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_52(void *, void *, void *, void *, int32_t);
void op_kernel_52(void **buffers, const int32_t *scalars) { op_impl_52(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_53(void *, void *, void *, void *, void *, int32_t);
void op_kernel_53(void **buffers, const int32_t *scalars) { op_impl_53(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_54(void *, void *, void *, void *, int32_t);
void op_kernel_54(void **buffers, const int32_t *scalars) { op_impl_54(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_55(void *, void *);
void op_kernel_55(void **buffers, const int32_t *scalars) { op_impl_55(buffers[0], buffers[1]); }
extern void op_impl_56(void *, void *, void *, void *, void *, int32_t);
void op_kernel_56(void **buffers, const int32_t *scalars) { op_impl_56(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_57(void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_57(void **buffers, const int32_t *scalars) { op_impl_57(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], scalars[0]); }
extern void op_impl_58(void *, void *, void *, void *);
void op_kernel_58(void **buffers, const int32_t *scalars) { op_impl_58(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_59(void *, void *, void *, void *);
void op_kernel_59(void **buffers, const int32_t *scalars) { op_impl_59(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_60(void *, void *, void *, void *);
void op_kernel_60(void **buffers, const int32_t *scalars) { op_impl_60(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_61(void *, void *, void *, void *);
void op_kernel_61(void **buffers, const int32_t *scalars) { op_impl_61(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_62(void *, void *, void *, void *, void *);
void op_kernel_62(void **buffers, const int32_t *scalars) { op_impl_62(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_63(void *, void *, void *, void *, void *);
void op_kernel_63(void **buffers, const int32_t *scalars) { op_impl_63(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_64(void *, void *, void *, void *);
void op_kernel_64(void **buffers, const int32_t *scalars) { op_impl_64(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_65(void *, void *, void *, void *);
void op_kernel_65(void **buffers, const int32_t *scalars) { op_impl_65(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_66(void *, void *, void *, void *, void *);
void op_kernel_66(void **buffers, const int32_t *scalars) { op_impl_66(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_67(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_67(void **buffers, const int32_t *scalars) { op_impl_67(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], buffers[6], buffers[7], buffers[8], buffers[9], buffers[10], buffers[11], buffers[12], buffers[13], buffers[14], buffers[15], buffers[16], buffers[17], buffers[18], buffers[19], buffers[20], buffers[21], buffers[22], buffers[23], buffers[24], buffers[25], buffers[26], buffers[27], buffers[28], buffers[29], buffers[30], buffers[31], buffers[32], buffers[33], scalars[0]); }
extern void op_impl_68(void *, void *, void *, void *);
void op_kernel_68(void **buffers, const int32_t *scalars) { op_impl_68(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_69(void *, void *, void *, void *, int32_t);
void op_kernel_69(void **buffers, const int32_t *scalars) { op_impl_69(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_70(void *, void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_70(void **buffers, const int32_t *scalars) { op_impl_70(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], buffers[6], scalars[0]); }
extern void op_impl_71(void *, void *);
void op_kernel_71(void **buffers, const int32_t *scalars) { op_impl_71(buffers[0], buffers[1]); }
extern void op_impl_72(void *, void *, void *);
void op_kernel_72(void **buffers, const int32_t *scalars) { op_impl_72(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_73(void *, void *, void *, void *, void *, void *);
void op_kernel_73(void **buffers, const int32_t *scalars) { op_impl_73(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5]); }
extern void op_impl_74(void *, void *, void *, void *, int32_t);
void op_kernel_74(void **buffers, const int32_t *scalars) { op_impl_74(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_75(void *, void *, void *);
void op_kernel_75(void **buffers, const int32_t *scalars) { op_impl_75(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_76(void *, void *);
void op_kernel_76(void **buffers, const int32_t *scalars) { op_impl_76(buffers[0], buffers[1]); }
extern void op_impl_77(void *, void *, void *);
void op_kernel_77(void **buffers, const int32_t *scalars) { op_impl_77(buffers[0], buffers[1], buffers[2]); }
extern void op_impl_78(void *, void *, void *, void *, void *);
void op_kernel_78(void **buffers, const int32_t *scalars) { op_impl_78(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_79(void *, void *, void *, void *, void *, int32_t);
void op_kernel_79(void **buffers, const int32_t *scalars) { op_impl_79(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_80(void *, void *, void *, void *, int32_t);
void op_kernel_80(void **buffers, const int32_t *scalars) { op_impl_80(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_81(void *, void *, void *, void *, void *, int32_t);
void op_kernel_81(void **buffers, const int32_t *scalars) { op_impl_81(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_82(void *, void *, void *, void *, int32_t);
void op_kernel_82(void **buffers, const int32_t *scalars) { op_impl_82(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_83(void *, void *, void *, void *, void *, int32_t);
void op_kernel_83(void **buffers, const int32_t *scalars) { op_impl_83(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_84(void *, void *, void *, void *, int32_t);
void op_kernel_84(void **buffers, const int32_t *scalars) { op_impl_84(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_85(void *, void *, void *, void *, void *, int32_t);
void op_kernel_85(void **buffers, const int32_t *scalars) { op_impl_85(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_86(void *, void *, void *, void *);
void op_kernel_86(void **buffers, const int32_t *scalars) { op_impl_86(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_87(void *, void *, void *, void *);
void op_kernel_87(void **buffers, const int32_t *scalars) { op_impl_87(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_88(void *, void *, void *, void *);
void op_kernel_88(void **buffers, const int32_t *scalars) { op_impl_88(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_89(void *, void *, void *, void *);
void op_kernel_89(void **buffers, const int32_t *scalars) { op_impl_89(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_90(void *, void *, void *, void *, void *);
void op_kernel_90(void **buffers, const int32_t *scalars) { op_impl_90(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_91(void *, void *, void *, void *, void *);
void op_kernel_91(void **buffers, const int32_t *scalars) { op_impl_91(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_92(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, int32_t);
void op_kernel_92(void **buffers, const int32_t *scalars) { op_impl_92(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], buffers[6], buffers[7], buffers[8], buffers[9], scalars[0]); }