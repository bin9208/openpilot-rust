#include <stdint.h>
#include <string.h>
void op_kernel_0(void **buffers, const int32_t *scalars) { memmove(buffers[0], buffers[1], 36); }
extern void op_impl_1(void *, void *, void *, int32_t);
void op_kernel_1(void **buffers, const int32_t *scalars) { op_impl_1(buffers[0], buffers[1], buffers[2], scalars[0]); }
void op_kernel_2(void **buffers, const int32_t *scalars) { memmove(buffers[0], buffers[1], 12); }
extern void op_impl_3(void *, void *, void *, void *, int32_t);
void op_kernel_3(void **buffers, const int32_t *scalars) { op_impl_3(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_4(void *, void *, void *, void *, int32_t);
void op_kernel_4(void **buffers, const int32_t *scalars) { op_impl_4(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_5(void *, void *, void *, void *, int32_t);
void op_kernel_5(void **buffers, const int32_t *scalars) { op_impl_5(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_6(void *, void *, void *, void *, int32_t);
void op_kernel_6(void **buffers, const int32_t *scalars) { op_impl_6(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_7(void *, void *, void *, void *, int32_t);
void op_kernel_7(void **buffers, const int32_t *scalars) { op_impl_7(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_8(void *, void *, void *, void *, int32_t);
void op_kernel_8(void **buffers, const int32_t *scalars) { op_impl_8(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_9(void *, void *, void *, void *, int32_t);
void op_kernel_9(void **buffers, const int32_t *scalars) { op_impl_9(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_10(void *, void *, void *, void *, int32_t);
void op_kernel_10(void **buffers, const int32_t *scalars) { op_impl_10(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_11(void *, void *, void *, void *, int32_t);
void op_kernel_11(void **buffers, const int32_t *scalars) { op_impl_11(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_12(void *, void *, void *, void *, int32_t);
void op_kernel_12(void **buffers, const int32_t *scalars) { op_impl_12(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_13(void *, void *, void *, void *, int32_t);
void op_kernel_13(void **buffers, const int32_t *scalars) { op_impl_13(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_14(void *, void *, void *, void *, void *, int32_t);
void op_kernel_14(void **buffers, const int32_t *scalars) { op_impl_14(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_15(void *, void *, void *, void *, int32_t);
void op_kernel_15(void **buffers, const int32_t *scalars) { op_impl_15(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_16(void *, void *, void *, void *, int32_t);
void op_kernel_16(void **buffers, const int32_t *scalars) { op_impl_16(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_17(void *, void *, void *, void *, void *, int32_t);
void op_kernel_17(void **buffers, const int32_t *scalars) { op_impl_17(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_18(void *, void *, void *, void *, int32_t);
void op_kernel_18(void **buffers, const int32_t *scalars) { op_impl_18(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_19(void *, void *, void *, void *, int32_t);
void op_kernel_19(void **buffers, const int32_t *scalars) { op_impl_19(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_20(void *, void *, void *, void *, int32_t);
void op_kernel_20(void **buffers, const int32_t *scalars) { op_impl_20(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_21(void *, void *, void *, void *, int32_t);
void op_kernel_21(void **buffers, const int32_t *scalars) { op_impl_21(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_22(void *, void *, void *, void *, int32_t);
void op_kernel_22(void **buffers, const int32_t *scalars) { op_impl_22(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_23(void *, void *, void *, void *, int32_t);
void op_kernel_23(void **buffers, const int32_t *scalars) { op_impl_23(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_24(void *, void *, void *, void *, void *, int32_t);
void op_kernel_24(void **buffers, const int32_t *scalars) { op_impl_24(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_25(void *, void *, void *, void *, int32_t);
void op_kernel_25(void **buffers, const int32_t *scalars) { op_impl_25(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_26(void *, void *, void *, void *, int32_t);
void op_kernel_26(void **buffers, const int32_t *scalars) { op_impl_26(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_27(void *, void *, void *, void *, void *, int32_t);
void op_kernel_27(void **buffers, const int32_t *scalars) { op_impl_27(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], scalars[0]); }
extern void op_impl_28(void *, void *, void *, void *, int32_t);
void op_kernel_28(void **buffers, const int32_t *scalars) { op_impl_28(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_29(void *, void *, void *, void *, int32_t);
void op_kernel_29(void **buffers, const int32_t *scalars) { op_impl_29(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_30(void *, void *, void *, void *, int32_t);
void op_kernel_30(void **buffers, const int32_t *scalars) { op_impl_30(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_31(void *, void *, void *, void *, int32_t);
void op_kernel_31(void **buffers, const int32_t *scalars) { op_impl_31(buffers[0], buffers[1], buffers[2], buffers[3], scalars[0]); }
extern void op_impl_32(void *, void *, void *, void *);
void op_kernel_32(void **buffers, const int32_t *scalars) { op_impl_32(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_33(void *, void *, void *, void *);
void op_kernel_33(void **buffers, const int32_t *scalars) { op_impl_33(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_34(void *, void *, void *, void *, void *);
void op_kernel_34(void **buffers, const int32_t *scalars) { op_impl_34(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4]); }
extern void op_impl_35(void *, void *, void *, void *);
void op_kernel_35(void **buffers, const int32_t *scalars) { op_impl_35(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_36(void *, void *, void *, void *);
void op_kernel_36(void **buffers, const int32_t *scalars) { op_impl_36(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_37(void *, void *, void *, void *);
void op_kernel_37(void **buffers, const int32_t *scalars) { op_impl_37(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_38(void *, void *, void *, void *);
void op_kernel_38(void **buffers, const int32_t *scalars) { op_impl_38(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_39(void *, void *, void *, void *);
void op_kernel_39(void **buffers, const int32_t *scalars) { op_impl_39(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_40(void *, void *, void *, void *);
void op_kernel_40(void **buffers, const int32_t *scalars) { op_impl_40(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_41(void *, void *, void *, void *);
void op_kernel_41(void **buffers, const int32_t *scalars) { op_impl_41(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_42(void *, void *, void *, void *);
void op_kernel_42(void **buffers, const int32_t *scalars) { op_impl_42(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_43(void *, void *, void *, void *);
void op_kernel_43(void **buffers, const int32_t *scalars) { op_impl_43(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_44(void *, void *, void *, void *);
void op_kernel_44(void **buffers, const int32_t *scalars) { op_impl_44(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_45(void *, void *, void *, void *);
void op_kernel_45(void **buffers, const int32_t *scalars) { op_impl_45(buffers[0], buffers[1], buffers[2], buffers[3]); }
extern void op_impl_46(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
void op_kernel_46(void **buffers, const int32_t *scalars) { op_impl_46(buffers[0], buffers[1], buffers[2], buffers[3], buffers[4], buffers[5], buffers[6], buffers[7], buffers[8], buffers[9], buffers[10], buffers[11], buffers[12], buffers[13], buffers[14], buffers[15], buffers[16], buffers[17], buffers[18], buffers[19], buffers[20], buffers[21], buffers[22], buffers[23], buffers[24], buffers[25], buffers[26], buffers[27], buffers[28], buffers[29], buffers[30], buffers[31], buffers[32], buffers[33], buffers[34], buffers[35], buffers[36], buffers[37], buffers[38], buffers[39], buffers[40], buffers[41], buffers[42], buffers[43], buffers[44], buffers[45], buffers[46]); }